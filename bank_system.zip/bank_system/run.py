"""
╔══════════════════════════════════════════════════════════════╗
║         BANCO SEGURO - Ponto de Entrada                      ║
║         Executa simulação e abre dashboard web               ║
╚══════════════════════════════════════════════════════════════╝

USO:
  python run.py             → simulação + dashboard web
  python run.py --sim-only  → apenas simulação no terminal
  python run.py --web-only  → apenas dashboard (sem sim)
  python run.py --port 8080 → porta customizada
"""

import sys
import os
import argparse
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    parser = argparse.ArgumentParser(description='Banco Seguro - Anti-Race Condition System')
    parser.add_argument('--sim-only', action='store_true', help='Apenas simulação no terminal')
    parser.add_argument('--web-only', action='store_true', help='Apenas dashboard web')
    parser.add_argument('--port', type=int, default=5000, help='Porta do servidor web (default: 5000)')
    args = parser.parse_args()

    if args.sim_only:
        # Apenas simulação
        from main import main as run_sim
        run_sim()
        return

    # Importa e configura sistema
    from main import setup_logging, BankSystem, simulate_concurrent_transfers
    from main import simulate_duplicate_attack, simulate_fraud_pattern
    setup_logging()

    bank = BankSystem()

    # Cria contas
    import logging
    logger = logging.getLogger("Run")
    logger.info("Inicializando contas de teste...")
    
    owners = ["Alice", "Bob", "Carol", "Dave", "Eve", "Frank"]
    accounts = []
    for name in owners:
        acc = bank.engine.create_account(name, initial_balance=5000.0, daily_limit=20000.0)
        accounts.append(acc)

    if not args.web_only:
        # Executa simulação em thread separada
        def run_sim():
            import time
            time.sleep(1)  # aguarda servidor subir
            logger.info("Iniciando simulação em background...")
            simulate_concurrent_transfers(bank, accounts, n_threads=20)
            import time; time.sleep(0.5)
            simulate_duplicate_attack(bank, accounts)
            time.sleep(0.5)
            simulate_fraud_pattern(bank, accounts)
            logger.info("Simulação inicial concluída. Dashboard disponível.")

        sim_thread = threading.Thread(target=run_sim, daemon=True)
        sim_thread.start()

    # Importa e inicia dashboard
    from dashboard.web_dashboard import run_web_dashboard
    run_web_dashboard(bank, port=args.port)


if __name__ == "__main__":
    main()
