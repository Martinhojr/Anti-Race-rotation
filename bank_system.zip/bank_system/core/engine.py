"""
╔══════════════════════════════════════════════════════════════╗
║         BANCO SEGURO - Motor Central Anti-Race Condition     ║
║         Arquitetura: Pessimistic Locking + MVCC + 2PL        ║
╚══════════════════════════════════════════════════════════════╝

ESTRATÉGIAS DE SEGURANÇA IMPLEMENTADAS:
  1. Two-Phase Locking (2PL) - garante serializabilidade
  2. Optimistic Concurrency Control (OCC) com versioning
  3. Deadlock Detection com grafo de dependências
  4. Idempotency Keys - previne transações duplicadas
  5. Write-Ahead Logging (WAL) - durabilidade e recuperação
  6. Circuit Breaker - protege contra cascata de falhas
"""

import threading
import time
import uuid
import hashlib
import json
import logging
from datetime import datetime, timedelta
from enum import Enum, auto
from dataclasses import dataclass, field, asdict
from typing import Dict, Optional, List, Tuple, Set, Callable
from collections import defaultdict
from contextlib import contextmanager
import queue


# ─────────────────────────────────────────────────────────────
# ENUMS E CONSTANTES
# ─────────────────────────────────────────────────────────────

class TransactionStatus(Enum):
    PENDING   = "PENDENTE"
    ACQUIRING = "ADQUIRINDO_LOCKS"
    EXECUTING = "EXECUTANDO"
    COMMITTED = "CONFIRMADA"
    ROLLED_BACK = "REVERTIDA"
    DEADLOCKED  = "DEADLOCK"
    TIMEOUT     = "TIMEOUT"
    DUPLICATE   = "DUPLICADA"

class LockType(Enum):
    SHARED    = "LEITURA"      # múltiplos leitores
    EXCLUSIVE = "ESCRITA"      # um único escritor

class CircuitState(Enum):
    CLOSED   = "FECHADO"       # operação normal
    OPEN     = "ABERTO"        # bloqueado por falhas
    HALF_OPEN = "SEMI_ABERTO"  # testando recuperação

class TransactionType(Enum):
    TRANSFER   = "TRANSFERÊNCIA"
    DEPOSIT    = "DEPÓSITO"
    WITHDRAWAL = "SAQUE"
    QUERY      = "CONSULTA"


# ─────────────────────────────────────────────────────────────
# MODELOS DE DADOS
# ─────────────────────────────────────────────────────────────

@dataclass
class Account:
    """Conta bancária com versionamento MVCC."""
    account_id: str
    owner: str
    balance: float
    version: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_updated: str = field(default_factory=lambda: datetime.now().isoformat())
    is_frozen: bool = False
    daily_limit: float = 10000.0
    daily_spent: float = 0.0
    daily_reset: str = field(default_factory=lambda: datetime.now().date().isoformat())

    def snapshot(self) -> dict:
        """Cria snapshot imutável para MVCC."""
        return asdict(self)


@dataclass
class Transaction:
    """Transação com rastreabilidade completa."""
    transaction_id: str
    idempotency_key: str
    tx_type: TransactionType
    from_account: Optional[str]
    to_account: Optional[str]
    amount: float
    status: TransactionStatus = TransactionStatus.PENDING
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None
    error_message: Optional[str] = None
    lock_acquired_at: Optional[str] = None
    execution_time_ms: float = 0.0
    retry_count: int = 0
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            **asdict(self),
            "tx_type": self.tx_type.value,
            "status": self.status.value,
        }


@dataclass
class LockEntry:
    """Entrada no gerenciador de locks."""
    account_id: str
    lock_type: LockType
    transaction_id: str
    acquired_at: float = field(default_factory=time.time)
    timeout_at: float = field(default_factory=lambda: time.time() + 30.0)


# ─────────────────────────────────────────────────────────────
# WRITE-AHEAD LOG (WAL)
# ─────────────────────────────────────────────────────────────

class WriteAheadLog:
    """
    WAL garante durabilidade: antes de qualquer operação,
    registramos a intenção. Em caso de crash, podemos replay.
    """

    def __init__(self):
        self._log: List[dict] = []
        self._lock = threading.Lock()
        self._sequence = 0
        self.logger = logging.getLogger("WAL")

    def write(self, transaction_id: str, operation: str, data: dict) -> int:
        with self._lock:
            self._sequence += 1
            entry = {
                "lsn": self._sequence,           # Log Sequence Number
                "transaction_id": transaction_id,
                "operation": operation,
                "data": data,
                "timestamp": datetime.now().isoformat(),
                "checksum": self._checksum(data)
            }
            self._log.append(entry)
            self.logger.debug(f"WAL LSN={self._sequence} TX={transaction_id[:8]} OP={operation}")
            return self._sequence

    def _checksum(self, data: dict) -> str:
        return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()[:16]

    def get_log(self) -> List[dict]:
        with self._lock:
            return list(self._log)

    def get_transaction_entries(self, transaction_id: str) -> List[dict]:
        with self._lock:
            return [e for e in self._log if e["transaction_id"] == transaction_id]


# ─────────────────────────────────────────────────────────────
# GERENCIADOR DE LOCKS (2PL)
# ─────────────────────────────────────────────────────────────

class LockManager:
    """
    Two-Phase Locking com detecção de deadlock.
    
    Fase 1 (Growing): transação adquire locks
    Fase 2 (Shrinking): transação libera locks
    
    DETECÇÃO DE DEADLOCK: grafo de espera (Wait-For Graph)
    Ciclos no grafo indicam deadlock → aborta transação mais nova.
    """

    def __init__(self):
        # account_id → [LockEntry]
        self._locks: Dict[str, List[LockEntry]] = defaultdict(list)
        # transaction_id → set(account_id) em espera
        self._waiting: Dict[str, Set[str]] = defaultdict(set)
        # transaction_id → set(account_id) mantendo
        self._held: Dict[str, Set[str]] = defaultdict(set)
        
        self._mutex = threading.Lock()
        self._conditions: Dict[str, threading.Condition] = {}
        self.logger = logging.getLogger("LockManager")
        
        # Inicia thread de limpeza de locks expirados
        self._cleanup_thread = threading.Thread(target=self._cleanup_loop, daemon=True)
        self._cleanup_thread.start()

    def acquire(self, account_id: str, lock_type: LockType,
                transaction_id: str, timeout: float = 10.0) -> bool:
        """
        Tenta adquirir lock. Bloqueia até conseguir ou timeout.
        Detecta deadlock antes de bloquear.
        """
        deadline = time.time() + timeout
        
        while time.time() < deadline:
            with self._mutex:
                if self._can_acquire(account_id, lock_type, transaction_id):
                    entry = LockEntry(account_id, lock_type, transaction_id,
                                      timeout_at=time.time() + 30.0)
                    self._locks[account_id].append(entry)
                    self._held[transaction_id].add(account_id)
                    self._waiting[transaction_id].discard(account_id)
                    self.logger.debug(
                        f"LOCK CONCEDIDO {lock_type.value} conta={account_id[:8]} "
                        f"tx={transaction_id[:8]}"
                    )
                    return True
                
                # Registra que esta transação está esperando
                self._waiting[transaction_id].add(account_id)
                
                # Checa deadlock ANTES de dormir
                if self._detect_deadlock(transaction_id):
                    self._waiting[transaction_id].discard(account_id)
                    self.logger.warning(f"DEADLOCK detectado tx={transaction_id[:8]}")
                    return False
            
            time.sleep(0.05)  # 50ms backoff
        
        with self._mutex:
            self._waiting[transaction_id].discard(account_id)
        
        self.logger.warning(f"TIMEOUT lock conta={account_id[:8]} tx={transaction_id[:8]}")
        return False

    def release_all(self, transaction_id: str):
        """Libera todos os locks de uma transação (fim da fase 2PL)."""
        with self._mutex:
            held = list(self._held.get(transaction_id, set()))
            for account_id in held:
                self._locks[account_id] = [
                    e for e in self._locks[account_id]
                    if e.transaction_id != transaction_id
                ]
            self._held.pop(transaction_id, None)
            self._waiting.pop(transaction_id, None)
            
            if held:
                self.logger.debug(f"LOCKS LIBERADOS tx={transaction_id[:8]} contas={len(held)}")

    def _can_acquire(self, account_id: str, lock_type: LockType, tx_id: str) -> bool:
        """Verifica compatibilidade de locks."""
        existing = self._locks.get(account_id, [])
        
        # Remove locks expirados
        now = time.time()
        existing = [e for e in existing if e.timeout_at > now]
        self._locks[account_id] = existing
        
        for entry in existing:
            if entry.transaction_id == tx_id:
                continue  # mesmo tx pode re-adquirir
            
            # EXCLUSIVO bloqueia tudo; COMPARTILHADO bloqueia EXCLUSIVO
            if lock_type == LockType.EXCLUSIVE or entry.lock_type == LockType.EXCLUSIVE:
                return False
        
        return True

    def _detect_deadlock(self, start_tx: str) -> bool:
        """
        BFS no grafo de espera (Wait-For Graph).
        Se encontrar ciclo envolvendo start_tx → deadlock.
        """
        visited = set()
        queue_bfs = [start_tx]
        
        while queue_bfs:
            current_tx = queue_bfs.pop(0)
            if current_tx in visited:
                return True  # ciclo encontrado!
            visited.add(current_tx)
            
            # Quem está segurando os locks que current_tx quer?
            for account_id in self._waiting.get(current_tx, set()):
                for entry in self._locks.get(account_id, []):
                    if entry.transaction_id != current_tx:
                        queue_bfs.append(entry.transaction_id)
        
        return False

    def _cleanup_loop(self):
        """Remove locks expirados periodicamente."""
        while True:
            time.sleep(5)
            with self._mutex:
                now = time.time()
                for account_id in list(self._locks.keys()):
                    expired = [e for e in self._locks[account_id] if e.timeout_at <= now]
                    for e in expired:
                        self.logger.warning(
                            f"LOCK EXPIRADO removido conta={account_id[:8]} "
                            f"tx={e.transaction_id[:8]}"
                        )
                    self._locks[account_id] = [
                        e for e in self._locks[account_id] if e.timeout_at > now
                    ]

    def get_status(self) -> dict:
        with self._mutex:
            total_locks = sum(len(v) for v in self._locks.values())
            return {
                "total_locks": total_locks,
                "locked_accounts": len([k for k, v in self._locks.items() if v]),
                "waiting_transactions": len(self._waiting),
                "held_transactions": len(self._held),
            }


# ─────────────────────────────────────────────────────────────
# IDEMPOTENCY MANAGER
# ─────────────────────────────────────────────────────────────

class IdempotencyManager:
    """
    Previne processamento duplicado de transações.
    Chave idempotente = hash(cliente + operação + valor + janela_temporal)
    """

    def __init__(self, ttl_seconds: int = 3600):
        self._store: Dict[str, Transaction] = {}
        self._lock = threading.Lock()
        self._ttl = ttl_seconds
        self.logger = logging.getLogger("Idempotency")

    def check_and_register(self, key: str, tx: Transaction) -> Optional[Transaction]:
        """
        Retorna transação existente se chave já usada,
        ou None se nova (e registra).
        """
        with self._lock:
            if key in self._store:
                existing = self._store[key]
                self.logger.warning(
                    f"DUPLICATA bloqueada key={key[:16]} "
                    f"tx_original={existing.transaction_id[:8]}"
                )
                return existing
            
            self._store[key] = tx
            return None

    def update(self, key: str, tx: Transaction):
        with self._lock:
            if key in self._store:
                self._store[key] = tx

    def cleanup_expired(self):
        """Remove entradas antigas."""
        with self._lock:
            cutoff = (datetime.now() - timedelta(seconds=self._ttl)).isoformat()
            expired = [k for k, v in self._store.items() if v.created_at < cutoff]
            for k in expired:
                del self._store[k]
            if expired:
                self.logger.info(f"Idempotency: {len(expired)} entradas expiradas removidas")


# ─────────────────────────────────────────────────────────────
# CIRCUIT BREAKER
# ─────────────────────────────────────────────────────────────

class CircuitBreaker:
    """
    Protege o sistema contra cascata de falhas.
    
    FECHADO → falhas normais acumulam
    ABERTO  → bloqueia chamadas por período de recovery
    SEMI    → deixa passar 1 chamada para testar
    """

    def __init__(self, name: str, failure_threshold: int = 5,
                 recovery_timeout: float = 30.0):
        self.name = name
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time = 0.0
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout
        self._lock = threading.Lock()
        self.logger = logging.getLogger(f"CircuitBreaker.{name}")

    def call(self, func: Callable, *args, **kwargs):
        """Executa função com proteção do circuit breaker."""
        with self._lock:
            state = self._evaluate_state()
        
        if state == CircuitState.OPEN:
            raise RuntimeError(f"Circuit Breaker [{self.name}] ABERTO - serviço indisponível")
        
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise

    def _evaluate_state(self) -> CircuitState:
        if self._state == CircuitState.OPEN:
            if time.time() - self._last_failure_time > self._recovery_timeout:
                self._state = CircuitState.HALF_OPEN
                self.logger.info(f"[{self.name}] → SEMI_ABERTO (testando)")
        return self._state

    def _on_success(self):
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.CLOSED
                self._failure_count = 0
                self.logger.info(f"[{self.name}] → FECHADO (recuperado)")

    def _on_failure(self):
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()
            if self._failure_count >= self._failure_threshold:
                self._state = CircuitState.OPEN
                self.logger.error(
                    f"[{self.name}] → ABERTO após {self._failure_count} falhas"
                )

    @property
    def state(self) -> CircuitState:
        return self._state

    def get_status(self) -> dict:
        return {
            "name": self.name,
            "state": self._state.value,
            "failure_count": self._failure_count,
            "failure_threshold": self._failure_threshold,
        }


# ─────────────────────────────────────────────────────────────
# MOTOR BANCÁRIO PRINCIPAL
# ─────────────────────────────────────────────────────────────

class BankingEngine:
    """
    Motor central que orquestra todas as estratégias anti-race condition.
    
    FLUXO DE UMA TRANSFERÊNCIA:
    1. Valida idempotency key → bloqueia duplicatas
    2. Registra intenção no WAL
    3. Adquire locks 2PL em ordem determinística (evita deadlock)
    4. Verifica versão MVCC (detecção de write-write conflict)
    5. Executa operação
    6. Atualiza versão
    7. Commit no WAL
    8. Libera locks
    """

    def __init__(self):
        self._accounts: Dict[str, Account] = {}
        self._transactions: Dict[str, Transaction] = {}
        self._account_lock = threading.RLock()
        
        self.wal = WriteAheadLog()
        self.lock_manager = LockManager()
        self.idempotency = IdempotencyManager()
        self.circuit_breaker = CircuitBreaker("banking_engine")
        
        self._event_listeners: List[Callable] = []
        self.logger = logging.getLogger("BankingEngine")
        
        # Métricas
        self._stats = {
            "total_transactions": 0,
            "committed": 0,
            "rolled_back": 0,
            "deadlocks": 0,
            "duplicates_blocked": 0,
            "timeouts": 0,
        }
        self._stats_lock = threading.Lock()

    # ── Contas ──────────────────────────────────────────────

    def create_account(self, owner: str, initial_balance: float = 0.0,
                       daily_limit: float = 10000.0) -> Account:
        account_id = str(uuid.uuid4())
        account = Account(
            account_id=account_id,
            owner=owner,
            balance=initial_balance,
            daily_limit=daily_limit,
        )
        with self._account_lock:
            self._accounts[account_id] = account
        
        self.wal.write("system", "CREATE_ACCOUNT", account.snapshot())
        self._emit_event("account_created", {"account": account.snapshot()})
        self.logger.info(f"Conta criada: {owner} id={account_id[:8]}")
        return account

    def get_account(self, account_id: str) -> Optional[Account]:
        with self._account_lock:
            return self._accounts.get(account_id)

    def get_all_accounts(self) -> List[Account]:
        with self._account_lock:
            return list(self._accounts.values())

    # ── Transferência ─────────────────────────────────────

    def transfer(self, from_id: str, to_id: str, amount: float,
                 idempotency_key: Optional[str] = None,
                 timeout: float = 15.0) -> Transaction:
        """
        Transferência segura com todas as proteções anti-race condition.
        """
        return self.circuit_breaker.call(
            self._transfer_internal, from_id, to_id, amount,
            idempotency_key, timeout
        )

    def _transfer_internal(self, from_id: str, to_id: str, amount: float,
                           idempotency_key: Optional[str], timeout: float) -> Transaction:
        start_time = time.time()
        tx_id = str(uuid.uuid4())
        idem_key = idempotency_key or f"{from_id}:{to_id}:{amount}:{int(time.time()//60)}"
        
        tx = Transaction(
            transaction_id=tx_id,
            idempotency_key=idem_key,
            tx_type=TransactionType.TRANSFER,
            from_account=from_id,
            to_account=to_id,
            amount=amount,
        )
        
        self._update_stats("total_transactions")

        # ── PASSO 1: Verificação de Idempotência ──────────
        existing = self.idempotency.check_and_register(idem_key, tx)
        if existing:
            tx.status = TransactionStatus.DUPLICATE
            self._update_stats("duplicates_blocked")
            self._emit_event("duplicate_blocked", {"transaction": tx.to_dict()})
            return existing

        # ── PASSO 2: WAL - Registra intenção ──────────────
        self.wal.write(tx_id, "TRANSFER_BEGIN", {
            "from": from_id, "to": to_id, "amount": amount
        })

        # ── PASSO 3: Validações básicas ───────────────────
        with self._account_lock:
            src = self._accounts.get(from_id)
            dst = self._accounts.get(to_id)
        
        if not src or not dst:
            return self._fail_tx(tx, "Conta não encontrada", start_time)
        if amount <= 0:
            return self._fail_tx(tx, "Valor inválido", start_time)
        if src.is_frozen or dst.is_frozen:
            return self._fail_tx(tx, "Conta bloqueada", start_time)
        
        # Verifica limite diário
        today = datetime.now().date().isoformat()
        if src.daily_reset != today:
            src.daily_spent = 0.0
            src.daily_reset = today
        if src.daily_spent + amount > src.daily_limit:
            return self._fail_tx(tx, f"Limite diário excedido (limite: R${src.daily_limit:.2f})", start_time)

        # ── PASSO 4: Adquire Locks 2PL ────────────────────
        # CRUCIAL: sempre adquire locks em ordem determinística
        # para evitar deadlock entre transações concorrentes
        tx.status = TransactionStatus.ACQUIRING
        lock_order = sorted([from_id, to_id])  # ordem lexicográfica
        
        acquired_locks = []
        try:
            for acc_id in lock_order:
                success = self.lock_manager.acquire(
                    acc_id, LockType.EXCLUSIVE, tx_id, timeout
                )
                if not success:
                    # Libera locks já adquiridos
                    self.lock_manager.release_all(tx_id)
                    status = TransactionStatus.DEADLOCKED if not success else TransactionStatus.TIMEOUT
                    tx.status = status
                    self._update_stats("deadlocks")
                    self.wal.write(tx_id, "DEADLOCK_ABORT", {})
                    self.idempotency.update(idem_key, tx)
                    self._emit_event("deadlock", {"transaction": tx.to_dict()})
                    return tx
                acquired_locks.append(acc_id)
            
            tx.lock_acquired_at = datetime.now().isoformat()
            tx.status = TransactionStatus.EXECUTING

            # ── PASSO 5: Verifica MVCC (snapshot no momento do lock) ──
            with self._account_lock:
                src = self._accounts[from_id]
                dst = self._accounts[to_id]
                
                src_version_before = src.version
                dst_version_before = dst.version

            # ── PASSO 6: Valida saldo ─────────────────────────────────
            if src.balance < amount:
                self.lock_manager.release_all(tx_id)
                return self._fail_tx(tx, f"Saldo insuficiente (R${src.balance:.2f})", start_time)

            # ── PASSO 7: Executa operação ─────────────────────────────
            self.wal.write(tx_id, "TRANSFER_EXECUTE", {
                "from_balance_before": src.balance,
                "to_balance_before": dst.balance,
                "amount": amount,
            })

            with self._account_lock:
                # Verifica que versão não mudou (proteção extra MVCC)
                if (self._accounts[from_id].version != src_version_before or
                        self._accounts[to_id].version != dst_version_before):
                    self.lock_manager.release_all(tx_id)
                    return self._fail_tx(tx, "Conflito de versão (MVCC) - tente novamente", start_time)
                
                # Débito e crédito atômicos
                self._accounts[from_id].balance -= amount
                self._accounts[from_id].version += 1
                self._accounts[from_id].daily_spent += amount
                self._accounts[from_id].last_updated = datetime.now().isoformat()
                
                self._accounts[to_id].balance += amount
                self._accounts[to_id].version += 1
                self._accounts[to_id].last_updated = datetime.now().isoformat()

            # ── PASSO 8: Commit ──────────────────────────────────────
            tx.status = TransactionStatus.COMMITTED
            tx.completed_at = datetime.now().isoformat()
            tx.execution_time_ms = (time.time() - start_time) * 1000

            self.wal.write(tx_id, "TRANSFER_COMMITTED", {
                "execution_ms": tx.execution_time_ms
            })

            self._transactions[tx_id] = tx
            self.idempotency.update(idem_key, tx)
            self._update_stats("committed")
            
            self._emit_event("transfer_committed", {
                "transaction": tx.to_dict(),
                "from_balance": self._accounts[from_id].balance,
                "to_balance": self._accounts[to_id].balance,
            })
            
            self.logger.info(
                f"✓ TRANSFERÊNCIA de={from_id[:8]} para={to_id[:8]} "
                f"R${amount:.2f} em {tx.execution_time_ms:.1f}ms"
            )
            return tx

        finally:
            self.lock_manager.release_all(tx_id)

    # ── Depósito ──────────────────────────────────────────

    def deposit(self, account_id: str, amount: float,
                idempotency_key: Optional[str] = None) -> Transaction:
        start_time = time.time()
        tx_id = str(uuid.uuid4())
        idem_key = idempotency_key or f"deposit:{account_id}:{amount}:{int(time.time()//60)}"
        
        tx = Transaction(
            transaction_id=tx_id,
            idempotency_key=idem_key,
            tx_type=TransactionType.DEPOSIT,
            from_account=None,
            to_account=account_id,
            amount=amount,
        )
        
        self._update_stats("total_transactions")
        
        existing = self.idempotency.check_and_register(idem_key, tx)
        if existing:
            self._update_stats("duplicates_blocked")
            return existing
        
        if amount <= 0:
            return self._fail_tx(tx, "Valor de depósito inválido", start_time)
        
        self.wal.write(tx_id, "DEPOSIT_BEGIN", {"account": account_id, "amount": amount})
        
        acquired = self.lock_manager.acquire(account_id, LockType.EXCLUSIVE, tx_id, 10.0)
        if not acquired:
            return self._fail_tx(tx, "Não foi possível adquirir lock", start_time)
        
        try:
            with self._account_lock:
                acc = self._accounts.get(account_id)
                if not acc:
                    return self._fail_tx(tx, "Conta não encontrada", start_time)
                if acc.is_frozen:
                    return self._fail_tx(tx, "Conta bloqueada", start_time)
                
                acc.balance += amount
                acc.version += 1
                acc.last_updated = datetime.now().isoformat()
            
            tx.status = TransactionStatus.COMMITTED
            tx.completed_at = datetime.now().isoformat()
            tx.execution_time_ms = (time.time() - start_time) * 1000
            
            self.wal.write(tx_id, "DEPOSIT_COMMITTED", {"new_balance": acc.balance})
            self._transactions[tx_id] = tx
            self.idempotency.update(idem_key, tx)
            self._update_stats("committed")
            self._emit_event("deposit_committed", {"transaction": tx.to_dict(), "balance": acc.balance})
            return tx
        finally:
            self.lock_manager.release_all(tx_id)

    # ── Saque ─────────────────────────────────────────────

    def withdraw(self, account_id: str, amount: float,
                 idempotency_key: Optional[str] = None) -> Transaction:
        start_time = time.time()
        tx_id = str(uuid.uuid4())
        idem_key = idempotency_key or f"withdraw:{account_id}:{amount}:{int(time.time()//60)}"
        
        tx = Transaction(
            transaction_id=tx_id,
            idempotency_key=idem_key,
            tx_type=TransactionType.WITHDRAWAL,
            from_account=account_id,
            to_account=None,
            amount=amount,
        )
        
        self._update_stats("total_transactions")
        
        existing = self.idempotency.check_and_register(idem_key, tx)
        if existing:
            self._update_stats("duplicates_blocked")
            return existing
        
        self.wal.write(tx_id, "WITHDRAW_BEGIN", {"account": account_id, "amount": amount})
        
        acquired = self.lock_manager.acquire(account_id, LockType.EXCLUSIVE, tx_id, 10.0)
        if not acquired:
            return self._fail_tx(tx, "Não foi possível adquirir lock", start_time)
        
        try:
            with self._account_lock:
                acc = self._accounts.get(account_id)
                if not acc:
                    return self._fail_tx(tx, "Conta não encontrada", start_time)
                if acc.is_frozen:
                    return self._fail_tx(tx, "Conta bloqueada", start_time)
                if acc.balance < amount:
                    return self._fail_tx(tx, f"Saldo insuficiente (R${acc.balance:.2f})", start_time)
                
                today = datetime.now().date().isoformat()
                if acc.daily_reset != today:
                    acc.daily_spent = 0.0
                    acc.daily_reset = today
                if acc.daily_spent + amount > acc.daily_limit:
                    return self._fail_tx(tx, "Limite diário excedido", start_time)
                
                acc.balance -= amount
                acc.daily_spent += amount
                acc.version += 1
                acc.last_updated = datetime.now().isoformat()
            
            tx.status = TransactionStatus.COMMITTED
            tx.completed_at = datetime.now().isoformat()
            tx.execution_time_ms = (time.time() - start_time) * 1000
            
            self.wal.write(tx_id, "WITHDRAW_COMMITTED", {"new_balance": acc.balance})
            self._transactions[tx_id] = tx
            self.idempotency.update(idem_key, tx)
            self._update_stats("committed")
            self._emit_event("withdrawal_committed", {"transaction": tx.to_dict(), "balance": acc.balance})
            return tx
        finally:
            self.lock_manager.release_all(tx_id)

    # ── Congelar/Descongelar conta ────────────────────────

    def freeze_account(self, account_id: str) -> bool:
        with self._account_lock:
            acc = self._accounts.get(account_id)
            if acc:
                acc.is_frozen = True
                self.wal.write("admin", "FREEZE_ACCOUNT", {"account_id": account_id})
                self._emit_event("account_frozen", {"account_id": account_id})
                return True
        return False

    def unfreeze_account(self, account_id: str) -> bool:
        with self._account_lock:
            acc = self._accounts.get(account_id)
            if acc:
                acc.is_frozen = False
                self.wal.write("admin", "UNFREEZE_ACCOUNT", {"account_id": account_id})
                self._emit_event("account_unfrozen", {"account_id": account_id})
                return True
        return False

    # ── Histórico ────────────────────────────────────────

    def get_transactions(self, account_id: Optional[str] = None,
                         limit: int = 50) -> List[Transaction]:
        txs = list(self._transactions.values())
        if account_id:
            txs = [t for t in txs
                   if t.from_account == account_id or t.to_account == account_id]
        txs.sort(key=lambda t: t.created_at, reverse=True)
        return txs[:limit]

    # ── Utilitários ──────────────────────────────────────

    def _fail_tx(self, tx: Transaction, error: str, start_time: float) -> Transaction:
        tx.status = TransactionStatus.ROLLED_BACK
        tx.error_message = error
        tx.completed_at = datetime.now().isoformat()
        tx.execution_time_ms = (time.time() - start_time) * 1000
        self._transactions[tx.transaction_id] = tx
        self.idempotency.update(tx.idempotency_key, tx)
        self._update_stats("rolled_back")
        self.wal.write(tx.transaction_id, "ROLLBACK", {"reason": error})
        self._emit_event("transaction_failed", {"transaction": tx.to_dict()})
        self.logger.warning(f"✗ TX FALHOU: {error} tx={tx.transaction_id[:8]}")
        return tx

    def _update_stats(self, key: str):
        with self._stats_lock:
            self._stats[key] = self._stats.get(key, 0) + 1

    def add_event_listener(self, callback: Callable):
        self._event_listeners.append(callback)

    def _emit_event(self, event_type: str, data: dict):
        event = {
            "event": event_type,
            "timestamp": datetime.now().isoformat(),
            "data": data,
        }
        for listener in self._event_listeners:
            try:
                listener(event)
            except Exception as e:
                self.logger.error(f"Erro em event listener: {e}")

    def get_stats(self) -> dict:
        with self._stats_lock:
            stats = dict(self._stats)
        stats["lock_status"] = self.lock_manager.get_status()
        stats["circuit_breaker"] = self.circuit_breaker.get_status()
        stats["wal_entries"] = len(self.wal.get_log())
        stats["total_accounts"] = len(self._accounts)
        return stats
