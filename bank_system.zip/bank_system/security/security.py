"""
╔══════════════════════════════════════════════════════════════╗
║         CAMADA DE SEGURANÇA                                  ║
║         Detecção de Fraude + Rate Limiting + Auditoria       ║
╚══════════════════════════════════════════════════════════════╝
"""

import threading
import time
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta
from collections import defaultdict, deque
from typing import Dict, List, Optional, Tuple
import logging


class RateLimiter:
    """
    Token Bucket + Sliding Window para controle de taxa.
    Previne ataques de força bruta e DDoS.
    """
    
    def __init__(self, requests_per_minute: int = 60, burst: int = 10):
        self._rpm = requests_per_minute
        self._burst = burst
        self._windows: Dict[str, deque] = defaultdict(deque)
        self._tokens: Dict[str, float] = defaultdict(lambda: float(burst))
        self._last_refill: Dict[str, float] = defaultdict(time.time)
        self._lock = threading.Lock()

    def is_allowed(self, client_id: str) -> Tuple[bool, dict]:
        """
        Verifica se request é permitido.
        Retorna (permitido, info).
        """
        with self._lock:
            now = time.time()
            
            # Token bucket refill
            elapsed = now - self._last_refill[client_id]
            refill = elapsed * (self._rpm / 60.0)
            self._tokens[client_id] = min(
                self._burst,
                self._tokens[client_id] + refill
            )
            self._last_refill[client_id] = now
            
            # Sliding window
            window = self._windows[client_id]
            window.append(now)
            cutoff = now - 60.0
            while window and window[0] < cutoff:
                window.popleft()
            
            requests_in_window = len(window)
            tokens = self._tokens[client_id]
            
            if tokens >= 1 and requests_in_window <= self._rpm:
                self._tokens[client_id] -= 1
                return True, {
                    "allowed": True,
                    "tokens_remaining": int(tokens - 1),
                    "requests_in_window": requests_in_window,
                    "limit": self._rpm,
                }
            else:
                return False, {
                    "allowed": False,
                    "tokens_remaining": int(tokens),
                    "requests_in_window": requests_in_window,
                    "limit": self._rpm,
                    "retry_after": 60 - (now - window[0]) if window else 60,
                }


class FraudDetector:
    """
    Detecção de padrões fraudulentos em tempo real.
    
    REGRAS:
    - Velocidade: muitas transações em curto período
    - Valor incomum: muito acima do histórico
    - Padrão geográfico: mudança brusca (simulado)
    - Round tripping: A→B→A em sequência rápida
    - Structuring: múltiplas transações abaixo de threshold
    """
    
    STRUCTURING_THRESHOLD = 9999.99   # USD 10k reporting rule
    VELOCITY_WINDOW = 300             # 5 minutos
    VELOCITY_LIMIT = 10              # max transações
    RAPID_TRANSFER_WINDOW = 60       # 1 minuto para round trip
    
    def __init__(self):
        self.logger = logging.getLogger("FraudDetector")
        self._tx_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        self._lock = threading.Lock()
        self._flagged: Dict[str, List[dict]] = defaultdict(list)

    def analyze(self, account_id: str, amount: float,
                to_account: Optional[str], tx_id: str) -> List[dict]:
        """
        Analisa transação e retorna lista de flags de risco.
        """
        flags = []
        with self._lock:
            now = time.time()
            history = self._tx_history[account_id]
            history.append({
                "ts": now,
                "amount": amount,
                "to": to_account,
                "tx_id": tx_id,
            })
            
            # Regra 1: Velocidade (muitas transações rápidas)
            recent = [t for t in history if now - t["ts"] < self.VELOCITY_WINDOW]
            if len(recent) > self.VELOCITY_LIMIT:
                flags.append({
                    "rule": "HIGH_VELOCITY",
                    "severity": "high",
                    "detail": f"{len(recent)} transações em {self.VELOCITY_WINDOW//60} min",
                })
            
            # Regra 2: Structuring (fragmentação abaixo do limite)
            recent_amounts = [t["amount"] for t in recent
                              if t["amount"] > self.STRUCTURING_THRESHOLD * 0.8
                              and t["amount"] < self.STRUCTURING_THRESHOLD]
            if len(recent_amounts) >= 3:
                flags.append({
                    "rule": "STRUCTURING",
                    "severity": "critical",
                    "detail": f"{len(recent_amounts)} transações suspeitas próximas ao limite",
                })
            
            # Regra 3: Round tripping (A→B e B→A rápido)
            if to_account:
                reverse = [t for t in history
                           if t.get("to") == account_id
                           and t["ts"] > now - self.RAPID_TRANSFER_WINDOW]
                if reverse:
                    flags.append({
                        "rule": "ROUND_TRIP",
                        "severity": "medium",
                        "detail": f"Transferência de retorno detectada em {self.RAPID_TRANSFER_WINDOW}s",
                    })
            
            # Regra 4: Valor muito alto isolado
            if len(history) > 5:
                amounts = [t["amount"] for t in list(history)[-20:]]
                avg = sum(amounts) / len(amounts)
                if amount > avg * 10 and amount > 5000:
                    flags.append({
                        "rule": "UNUSUAL_AMOUNT",
                        "severity": "medium",
                        "detail": f"R${amount:.2f} é {amount/avg:.1f}x acima da média histórica",
                    })
            
            if flags:
                for flag in flags:
                    flag["account_id"] = account_id
                    flag["tx_id"] = tx_id
                    flag["timestamp"] = datetime.now().isoformat()
                self._flagged[account_id].extend(flags)
                self.logger.warning(
                    f"FRAUDE DETECTADA conta={account_id[:8]} "
                    f"regras={[f['rule'] for f in flags]}"
                )
        
        return flags

    def get_risk_score(self, account_id: str) -> int:
        """Retorna score de risco 0-100."""
        with self._lock:
            flags = self._flagged.get(account_id, [])
            if not flags:
                return 0
            
            score = 0
            severity_scores = {"low": 10, "medium": 25, "high": 50, "critical": 80}
            for f in flags[-10:]:  # considera últimas 10 flags
                score += severity_scores.get(f.get("severity", "low"), 10)
            return min(100, score)

    def get_all_flags(self) -> List[dict]:
        with self._lock:
            all_flags = []
            for flags in self._flagged.values():
                all_flags.extend(flags)
            all_flags.sort(key=lambda f: f["timestamp"], reverse=True)
            return all_flags[:100]


class AuditLogger:
    """
    Log de auditoria imutável para compliance.
    Cada entrada tem hash encadeado (blockchain-like).
    """
    
    def __init__(self):
        self._entries: List[dict] = []
        self._lock = threading.Lock()
        self._prev_hash = "0" * 64
        self.logger = logging.getLogger("Audit")

    def log(self, actor: str, action: str, resource: str,
            details: dict, outcome: str = "success"):
        with self._lock:
            entry_data = {
                "actor": actor,
                "action": action,
                "resource": resource,
                "details": details,
                "outcome": outcome,
                "timestamp": datetime.now().isoformat(),
                "prev_hash": self._prev_hash,
            }
            
            # Hash encadeado garante imutabilidade
            import json
            entry_str = json.dumps(entry_data, sort_keys=True)
            current_hash = hashlib.sha256(entry_str.encode()).hexdigest()
            
            entry = {**entry_data, "hash": current_hash, "seq": len(self._entries) + 1}
            self._entries.append(entry)
            self._prev_hash = current_hash
        
        self.logger.info(f"AUDIT {action} by={actor} resource={resource} outcome={outcome}")

    def verify_integrity(self) -> Tuple[bool, Optional[int]]:
        """Verifica integridade da cadeia de hashes."""
        import json
        with self._lock:
            prev = "0" * 64
            for i, entry in enumerate(self._entries):
                data = {k: v for k, v in entry.items() if k not in ("hash", "seq")}
                expected = hashlib.sha256(
                    json.dumps(data, sort_keys=True).encode()
                ).hexdigest()
                if entry["hash"] != expected or entry.get("prev_hash") != prev:
                    return False, i + 1
                prev = entry["hash"]
        return True, None

    def get_entries(self, limit: int = 50) -> List[dict]:
        with self._lock:
            return list(reversed(self._entries[-limit:]))


class SecurityLayer:
    """Fachada da camada de segurança."""
    
    def __init__(self):
        self.rate_limiter = RateLimiter(requests_per_minute=120, burst=20)
        self.fraud_detector = FraudDetector()
        self.audit_logger = AuditLogger()
        self.logger = logging.getLogger("Security")

    def check_request(self, client_id: str) -> Tuple[bool, str]:
        allowed, info = self.rate_limiter.is_allowed(client_id)
        if not allowed:
            self.audit_logger.log(
                client_id, "REQUEST_RATE_LIMITED", "api",
                info, "blocked"
            )
            return False, f"Rate limit excedido. Tente em {info.get('retry_after', 60):.0f}s"
        return True, "ok"

    def analyze_transaction(self, account_id: str, amount: float,
                            to_account: Optional[str], tx_id: str) -> List[dict]:
        flags = self.fraud_detector.analyze(account_id, amount, to_account, tx_id)
        if flags:
            self.audit_logger.log(
                "system", "FRAUD_FLAGS", account_id,
                {"flags": flags, "amount": amount}, "flagged"
            )
        return flags

    def get_security_report(self) -> dict:
        integrity_ok, broken_at = self.audit_logger.verify_integrity()
        return {
            "audit_integrity": integrity_ok,
            "integrity_broken_at": broken_at,
            "fraud_flags": self.fraud_detector.get_all_flags(),
            "audit_log": self.audit_logger.get_entries(20),
            "timestamp": datetime.now().isoformat(),
        }
