"""
╔══════════════════════════════════════════════════════════════╗
║         SISTEMA DE MONITORAMENTO EM TEMPO REAL               ║
║         Métricas, Alertas, Detecção de Anomalias             ║
╚══════════════════════════════════════════════════════════════╝
"""

import threading
import time
import queue
from datetime import datetime, timedelta
from collections import deque, defaultdict
from typing import List, Dict, Callable, Optional
import logging
import statistics


class MetricsSeries:
    """Série temporal de métricas com janela deslizante."""
    
    def __init__(self, name: str, window_seconds: int = 60):
        self.name = name
        self.window = window_seconds
        self._data: deque = deque()
        self._lock = threading.Lock()

    def record(self, value: float, timestamp: Optional[float] = None):
        ts = timestamp or time.time()
        with self._lock:
            self._data.append((ts, value))
            self._purge()

    def _purge(self):
        cutoff = time.time() - self.window
        while self._data and self._data[0][0] < cutoff:
            self._data.popleft()

    def get_stats(self) -> dict:
        with self._lock:
            self._purge()
            if not self._data:
                return {"count": 0, "mean": 0, "min": 0, "max": 0, "latest": 0}
            values = [v for _, v in self._data]
            return {
                "count": len(values),
                "mean": round(statistics.mean(values), 3),
                "min": round(min(values), 3),
                "max": round(max(values), 3),
                "latest": round(values[-1], 3),
                "p95": round(sorted(values)[int(len(values)*0.95)] if len(values) > 1 else values[-1], 3),
            }

    def get_series(self, points: int = 30) -> List[dict]:
        """Retorna série para gráfico."""
        with self._lock:
            self._purge()
            data = list(self._data)
        
        if not data:
            return []
        
        # Agrega em buckets
        if len(data) <= points:
            return [{"t": ts, "v": v} for ts, v in data]
        
        bucket_size = len(data) // points
        result = []
        for i in range(0, len(data), bucket_size):
            bucket = data[i:i+bucket_size]
            if bucket:
                result.append({
                    "t": bucket[-1][0],
                    "v": round(statistics.mean(v for _, v in bucket), 3)
                })
        return result[-points:]


class AlertRule:
    """Regra de alerta configurável."""
    
    def __init__(self, name: str, metric: str, threshold: float,
                 condition: str = "gt", severity: str = "warning",
                 cooldown: int = 60):
        self.name = name
        self.metric = metric          # nome da métrica
        self.threshold = threshold
        self.condition = condition    # gt, lt, eq
        self.severity = severity      # info, warning, critical
        self.cooldown = cooldown      # segundos entre alertas
        self._last_fired = 0.0

    def evaluate(self, value: float) -> bool:
        if time.time() - self._last_fired < self.cooldown:
            return False
        
        triggered = False
        if self.condition == "gt" and value > self.threshold:
            triggered = True
        elif self.condition == "lt" and value < self.threshold:
            triggered = True
        elif self.condition == "eq" and value == self.threshold:
            triggered = True
        
        if triggered:
            self._last_fired = time.time()
        return triggered


class AnomalyDetector:
    """
    Detecção de anomalias por Z-Score e IQR.
    Identifica transações suspeitas por padrão estatístico.
    """
    
    def __init__(self, window: int = 100):
        self._values: deque = deque(maxlen=window)
        self._lock = threading.Lock()

    def add(self, value: float) -> float:
        """Retorna Z-Score da observação."""
        with self._lock:
            self._values.append(value)
            if len(self._values) < 10:
                return 0.0
            
            vals = list(self._values)
            mean = statistics.mean(vals)
            stdev = statistics.stdev(vals) or 0.001
            return abs((value - mean) / stdev)

    def is_anomaly(self, value: float, z_threshold: float = 3.0) -> bool:
        return self.add(value) > z_threshold


class RealTimeMonitor:
    """
    Sistema de monitoramento em tempo real.
    
    Coleta métricas de todos os componentes e detecta anomalias.
    """

    def __init__(self):
        self.logger = logging.getLogger("Monitor")
        
        # Séries temporais
        self.metrics = {
            "tx_per_second": MetricsSeries("Transações/s", 300),
            "tx_latency_ms": MetricsSeries("Latência TX (ms)", 300),
            "active_locks": MetricsSeries("Locks Ativos", 300),
            "deadlocks": MetricsSeries("Deadlocks", 3600),
            "balance_transferred": MetricsSeries("Volume Transferido", 3600),
            "tx_success_rate": MetricsSeries("Taxa de Sucesso %", 300),
            "duplicates_blocked": MetricsSeries("Duplicatas Bloqueadas", 3600),
        }
        
        # Contadores de janela
        self._tx_window: deque = deque()
        self._window_lock = threading.Lock()
        
        # Alertas
        self.alert_rules = [
            AlertRule("Alta Latência", "tx_latency_ms", 500, "gt", "warning"),
            AlertRule("Latência Crítica", "tx_latency_ms", 2000, "gt", "critical"),
            AlertRule("Deadlocks Frequentes", "deadlocks", 3, "gt", "critical", 300),
            AlertRule("Taxa de Sucesso Baixa", "tx_success_rate", 80, "lt", "warning"),
        ]
        
        self._alerts: deque = deque(maxlen=200)
        self._alert_listeners: List[Callable] = []
        
        # Detecção de anomalias
        self._amount_anomaly = AnomalyDetector()
        self._latency_anomaly = AnomalyDetector()
        
        # Estatísticas acumuladas
        self._total_committed = 0
        self._total_failed = 0
        self._total_volume = 0.0
        
        # Thread de polling
        self._running = True
        self._poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._poll_thread.start()

    def on_event(self, event: dict):
        """Recebe eventos do BankingEngine e atualiza métricas."""
        ev_type = event["event"]
        data = event.get("data", {})
        now = time.time()
        
        with self._window_lock:
            self._tx_window.append(now)
            # Purga entradas > 1 segundo
            cutoff = now - 1.0
            while self._tx_window and self._tx_window[0] < cutoff:
                self._tx_window.popleft()
        
        if ev_type in ("transfer_committed", "deposit_committed", "withdrawal_committed"):
            self._total_committed += 1
            tx = data.get("transaction", {})
            latency = tx.get("execution_time_ms", 0)
            amount = tx.get("amount", 0)
            
            self.metrics["tx_latency_ms"].record(latency)
            
            if ev_type == "transfer_committed":
                self._total_volume += amount
                self.metrics["balance_transferred"].record(amount)
            
            # Detecta anomalia de valor
            z = self._amount_anomaly.add(amount)
            if z > 3.0:
                self._fire_alert("Anomalia de Valor", "critical",
                    f"Transação R${amount:.2f} é {z:.1f}σ acima da média")
            
            # Detecta anomalia de latência
            z_lat = self._latency_anomaly.add(latency)
            if z_lat > 3.0:
                self._fire_alert("Anomalia de Latência", "warning",
                    f"Latência {latency:.1f}ms é {z_lat:.1f}σ acima da média")
            
            # Avalia regras de alerta
            for rule in self.alert_rules:
                if rule.metric == "tx_latency_ms":
                    if rule.evaluate(latency):
                        self._fire_alert(rule.name, rule.severity,
                            f"Latência {latency:.1f}ms excedeu {rule.threshold}ms")
        
        elif ev_type == "transaction_failed":
            self._total_failed += 1
        
        elif ev_type == "deadlock":
            self.metrics["deadlocks"].record(1)
            self._fire_alert("Deadlock Detectado", "warning",
                "Transação abortada por deadlock")
        
        elif ev_type == "duplicate_blocked":
            self.metrics["duplicates_blocked"].record(1)

    def _poll_loop(self):
        """Atualiza métricas derivadas periodicamente."""
        while self._running:
            time.sleep(1)
            
            with self._window_lock:
                tps = len(self._tx_window)
            self.metrics["tx_per_second"].record(tps)
            
            total = self._total_committed + self._total_failed
            if total > 0:
                rate = (self._total_committed / total) * 100
                self.metrics["tx_success_rate"].record(rate)
                
                for rule in self.alert_rules:
                    if rule.metric == "tx_success_rate":
                        if rule.evaluate(rate):
                            self._fire_alert(rule.name, rule.severity,
                                f"Taxa de sucesso {rate:.1f}% abaixo de {rule.threshold}%")

    def _fire_alert(self, name: str, severity: str, message: str):
        alert = {
            "id": f"ALT-{int(time.time()*1000) % 100000:05d}",
            "name": name,
            "severity": severity,
            "message": message,
            "timestamp": datetime.now().isoformat(),
        }
        self._alerts.appendleft(alert)
        self.logger.warning(f"[{severity.upper()}] {name}: {message}")
        for listener in self._alert_listeners:
            try:
                listener(alert)
            except Exception:
                pass

    def add_alert_listener(self, callback: Callable):
        self._alert_listeners.append(callback)

    def get_dashboard_data(self) -> dict:
        """Dados para o dashboard em tempo real."""
        with self._window_lock:
            tps = len(self._tx_window)
        
        total = self._total_committed + self._total_failed
        success_rate = (self._total_committed / total * 100) if total > 0 else 100.0
        
        return {
            "summary": {
                "tps": tps,
                "total_committed": self._total_committed,
                "total_failed": self._total_failed,
                "total_volume": round(self._total_volume, 2),
                "success_rate": round(success_rate, 1),
            },
            "metrics": {
                name: {
                    "stats": series.get_stats(),
                    "series": series.get_series(20),
                }
                for name, series in self.metrics.items()
            },
            "alerts": list(self._alerts)[:20],
            "timestamp": datetime.now().isoformat(),
        }

    def stop(self):
        self._running = False
