"""
╔══════════════════════════════════════════════════════════════╗
║         DASHBOARD WEB EM TEMPO REAL                          ║
║         Flask API + HTML Dashboard                           ║
╚══════════════════════════════════════════════════════════════╝
"""

DASHBOARD_HTML = '''<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🏦 Banco Seguro - Monitor</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;600;700&family=Syne:wght@400;600;800&display=swap');

  :root {
    --bg: #060910;
    --surface: #0d1117;
    --surface2: #141b24;
    --border: #1e2d40;
    --accent: #00d4ff;
    --accent2: #00ff88;
    --warn: #ffb347;
    --danger: #ff4757;
    --text: #c9d1d9;
    --text2: #6e7681;
    --glow: 0 0 20px rgba(0,212,255,0.15);
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }
  
  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'JetBrains Mono', monospace;
    min-height: 100vh;
    overflow-x: hidden;
  }

  /* Animated background grid */
  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image:
      linear-gradient(rgba(0,212,255,0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,212,255,0.03) 1px, transparent 1px);
    background-size: 40px 40px;
    pointer-events: none;
    z-index: 0;
  }

  .app { position: relative; z-index: 1; }

  /* HEADER */
  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 32px;
    border-bottom: 1px solid var(--border);
    background: rgba(6,9,16,0.9);
    backdrop-filter: blur(10px);
    position: sticky; top: 0; z-index: 100;
  }

  .logo {
    display: flex; align-items: center; gap: 12px;
  }
  .logo-icon {
    width: 36px; height: 36px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px;
  }
  .logo-text {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 18px;
    color: #fff;
    letter-spacing: -0.5px;
  }
  .logo-sub { font-size: 10px; color: var(--text2); letter-spacing: 2px; text-transform: uppercase; }

  .header-right { display: flex; align-items: center; gap: 16px; }

  .status-badge {
    display: flex; align-items: center; gap: 6px;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
  }
  .status-badge.live {
    background: rgba(0,255,136,0.1);
    border: 1px solid rgba(0,255,136,0.3);
    color: var(--accent2);
  }
  .status-dot {
    width: 6px; height: 6px; border-radius: 50%;
    background: var(--accent2);
    animation: pulse 1.5s infinite;
  }
  @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(1.5)} }

  .last-update { font-size: 10px; color: var(--text2); }

  /* MAIN GRID */
  .main-grid {
    display: grid;
    grid-template-columns: 280px 1fr;
    gap: 0;
    min-height: calc(100vh - 65px);
  }

  /* SIDEBAR */
  .sidebar {
    border-right: 1px solid var(--border);
    padding: 20px;
    display: flex; flex-direction: column; gap: 20px;
    overflow-y: auto;
  }

  .section-title {
    font-size: 9px; font-weight: 600; letter-spacing: 3px;
    text-transform: uppercase; color: var(--text2);
    margin-bottom: 10px;
  }

  /* KPI cards */
  .kpi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  
  .kpi-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px;
    transition: all 0.2s;
  }
  .kpi-card:hover { border-color: var(--accent); box-shadow: var(--glow); }
  
  .kpi-label { font-size: 9px; color: var(--text2); letter-spacing: 1px; text-transform: uppercase; margin-bottom: 4px; }
  .kpi-value { font-size: 20px; font-weight: 700; color: #fff; line-height: 1; }
  .kpi-value.accent { color: var(--accent); }
  .kpi-value.success { color: var(--accent2); }
  .kpi-value.warn { color: var(--warn); }
  .kpi-value.danger { color: var(--danger); }
  .kpi-sub { font-size: 9px; color: var(--text2); margin-top: 4px; }

  /* Circuit Breaker */
  .circuit-panel {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px;
  }
  .circuit-state {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 4px 10px; border-radius: 4px;
    font-size: 11px; font-weight: 600;
    margin-top: 6px;
  }
  .circuit-state.FECHADO { background: rgba(0,255,136,0.1); color: var(--accent2); border: 1px solid rgba(0,255,136,0.2); }
  .circuit-state.ABERTO { background: rgba(255,71,87,0.1); color: var(--danger); border: 1px solid rgba(255,71,87,0.2); }
  .circuit-state.SEMI_ABERTO { background: rgba(255,179,71,0.1); color: var(--warn); border: 1px solid rgba(255,179,71,0.2); }

  /* Accounts list */
  .account-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 10px 12px;
    margin-bottom: 6px;
    transition: all 0.2s;
    cursor: pointer;
  }
  .account-card:hover { border-color: var(--accent); }
  .account-card.frozen { border-color: var(--danger); opacity: 0.7; }
  .account-card.high-risk { border-color: var(--warn); }
  
  .account-header { display: flex; justify-content: space-between; align-items: center; }
  .account-name { font-size: 13px; font-weight: 600; color: #fff; }
  .account-balance { font-size: 13px; color: var(--accent2); font-weight: 700; }
  .account-meta { display: flex; gap: 8px; margin-top: 4px; font-size: 9px; color: var(--text2); }
  .account-tag {
    padding: 1px 6px; border-radius: 3px; font-size: 9px; font-weight: 600;
    letter-spacing: 0.5px;
  }
  .tag-frozen { background: rgba(255,71,87,0.15); color: var(--danger); }
  .tag-risk { background: rgba(255,179,71,0.15); color: var(--warn); }

  /* MAIN CONTENT */
  .content { padding: 20px; overflow-y: auto; display: flex; flex-direction: column; gap: 20px; }

  /* Charts row */
  .charts-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

  .chart-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px;
  }
  .chart-title { font-size: 11px; font-weight: 600; color: var(--text2); letter-spacing: 1px; text-transform: uppercase; margin-bottom: 12px; display: flex; justify-content: space-between; }
  .chart-value { font-size: 24px; font-weight: 700; color: #fff; }

  /* Sparkline */
  .sparkline-container { position: relative; height: 60px; }
  canvas.sparkline { width: 100% !important; height: 60px !important; }

  /* Transactions table */
  .table-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
  }
  .table-header {
    padding: 14px 16px;
    border-bottom: 1px solid var(--border);
    display: flex; justify-content: space-between; align-items: center;
  }
  .table-title { font-size: 12px; font-weight: 600; color: var(--text); letter-spacing: 0.5px; }

  table { width: 100%; border-collapse: collapse; }
  th {
    padding: 8px 16px;
    text-align: left;
    font-size: 9px; font-weight: 600;
    letter-spacing: 2px; text-transform: uppercase;
    color: var(--text2);
    border-bottom: 1px solid var(--border);
    background: var(--surface2);
  }
  td { padding: 9px 16px; font-size: 11px; border-bottom: 1px solid rgba(30,45,64,0.5); }
  tr:hover td { background: rgba(0,212,255,0.03); }

  .tx-status {
    padding: 2px 8px; border-radius: 4px;
    font-size: 9px; font-weight: 700; letter-spacing: 0.5px; text-transform: uppercase;
  }
  .status-CONFIRMADA { background: rgba(0,255,136,0.1); color: var(--accent2); }
  .status-REVERTIDA { background: rgba(255,71,87,0.1); color: var(--danger); }
  .status-PENDENTE { background: rgba(0,212,255,0.1); color: var(--accent); }
  .status-DEADLOCK { background: rgba(255,71,87,0.2); color: var(--danger); }
  .status-DUPLICADA { background: rgba(255,179,71,0.1); color: var(--warn); }
  .status-TIMEOUT { background: rgba(255,179,71,0.1); color: var(--warn); }

  .tx-type { color: var(--text2); font-size: 10px; }
  .tx-amount { color: #fff; font-weight: 600; }
  .tx-time { color: var(--text2); font-size: 10px; }

  /* Alerts */
  .alerts-panel {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
  }
  .alert-item {
    padding: 10px 16px;
    border-bottom: 1px solid rgba(30,45,64,0.5);
    display: flex; align-items: flex-start; gap: 10px;
    animation: slideIn 0.3s ease;
  }
  @keyframes slideIn { from{opacity:0;transform:translateY(-10px)} to{opacity:1;transform:translateY(0)} }
  
  .alert-dot {
    width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; margin-top: 4px;
  }
  .alert-dot.warning { background: var(--warn); }
  .alert-dot.critical { background: var(--danger); box-shadow: 0 0 8px var(--danger); }
  .alert-dot.info { background: var(--accent); }
  .alert-name { font-size: 11px; font-weight: 600; color: #fff; }
  .alert-msg { font-size: 10px; color: var(--text2); margin-top: 2px; }
  .alert-time { font-size: 9px; color: var(--text2); margin-left: auto; white-space: nowrap; }

  /* WAL / Audit log */
  .log-panel {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
  }
  .log-entry {
    padding: 6px 16px;
    font-size: 10px;
    border-bottom: 1px solid rgba(30,45,64,0.3);
    display: grid;
    grid-template-columns: 80px 80px 1fr;
    gap: 12px;
    color: var(--text2);
  }
  .log-entry .op { color: var(--accent); font-weight: 600; }
  .log-entry .lsn { color: var(--text2); }

  /* Controls */
  .controls { display: flex; gap: 8px; flex-wrap: wrap; }
  .btn {
    padding: 7px 16px;
    border-radius: 6px;
    border: 1px solid var(--border);
    background: var(--surface2);
    color: var(--text);
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px; font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    letter-spacing: 0.5px;
  }
  .btn:hover { border-color: var(--accent); color: var(--accent); background: rgba(0,212,255,0.05); }
  .btn.primary { background: rgba(0,212,255,0.1); border-color: var(--accent); color: var(--accent); }
  .btn.danger { background: rgba(255,71,87,0.1); border-color: var(--danger); color: var(--danger); }
  .btn.success { background: rgba(0,255,136,0.1); border-color: var(--accent2); color: var(--accent2); }
  .btn:disabled { opacity: 0.4; cursor: not-allowed; }

  /* Transfer form */
  .form-row { display: flex; gap: 8px; align-items: flex-end; flex-wrap: wrap; }
  .form-group { display: flex; flex-direction: column; gap: 4px; }
  .form-label { font-size: 9px; color: var(--text2); letter-spacing: 1px; text-transform: uppercase; }
  .form-input, .form-select {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 7px 12px;
    color: var(--text);
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    outline: none;
    transition: border-color 0.2s;
    min-width: 140px;
  }
  .form-input:focus, .form-select:focus { border-color: var(--accent); }
  .form-select option { background: var(--surface); }

  /* Security */
  .security-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

  .integrity-badge {
    display: flex; align-items: center; gap: 8px;
    padding: 8px 14px; border-radius: 6px;
    font-size: 12px; font-weight: 600;
  }
  .integrity-badge.ok { background: rgba(0,255,136,0.1); color: var(--accent2); border: 1px solid rgba(0,255,136,0.2); }
  .integrity-badge.fail { background: rgba(255,71,87,0.1); color: var(--danger); border: 1px solid rgba(255,71,87,0.2); }

  .empty-state { padding: 20px; text-align: center; color: var(--text2); font-size: 11px; }

  /* WAL area */
  .wal-area {
    max-height: 180px; overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: var(--border) transparent;
  }

  /* Scrollbar */
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

  /* Lock visualization */
  .lock-viz {
    display: flex; gap: 4px; flex-wrap: wrap; margin-top: 8px;
  }
  .lock-pill {
    padding: 2px 8px; border-radius: 3px;
    font-size: 9px; font-weight: 600;
    background: rgba(255,71,87,0.15);
    color: var(--danger);
    border: 1px solid rgba(255,71,87,0.2);
    animation: lockPulse 1s infinite;
  }
  @keyframes lockPulse { 0%,100%{opacity:1} 50%{opacity:0.5} }

  .no-locks { font-size: 10px; color: var(--accent2); }

  /* Responsive */
  @media (max-width: 1000px) {
    .main-grid { grid-template-columns: 1fr; }
    .sidebar { border-right: none; border-bottom: 1px solid var(--border); }
    .charts-row { grid-template-columns: 1fr; }
    .security-grid { grid-template-columns: 1fr; }
  }
</style>
</head>
<body>
<div class="app">

<!-- HEADER -->
<header>
  <div class="logo">
    <div class="logo-icon">🏦</div>
    <div>
      <div class="logo-text">BANCO SEGURO</div>
      <div class="logo-sub">Anti-Race Condition System</div>
    </div>
  </div>
  <div class="header-right">
    <div class="last-update" id="lastUpdate">—</div>
    <div class="status-badge live">
      <div class="status-dot"></div>
      AO VIVO
    </div>
  </div>
</header>

<div class="main-grid">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div>
      <div class="section-title">KPIs em Tempo Real</div>
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-label">TX/s</div>
          <div class="kpi-value accent" id="kpiTPS">0</div>
          <div class="kpi-sub">transações/seg</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Sucesso</div>
          <div class="kpi-value success" id="kpiSuccessRate">100%</div>
          <div class="kpi-sub">taxa geral</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Confirmadas</div>
          <div class="kpi-value" id="kpiCommitted">0</div>
          <div class="kpi-sub">total</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Falhas</div>
          <div class="kpi-value danger" id="kpiFailed">0</div>
          <div class="kpi-sub">revertidas</div>
        </div>
        <div class="kpi-card" style="grid-column:1/-1">
          <div class="kpi-label">Volume Transferido</div>
          <div class="kpi-value accent" id="kpiVolume">R$ 0</div>
          <div class="kpi-sub">acumulado</div>
        </div>
      </div>
    </div>

    <div>
      <div class="section-title">Circuit Breaker</div>
      <div class="circuit-panel">
        <div style="font-size:10px;color:var(--text2)">Estado do sistema</div>
        <div id="circuitState" class="circuit-state FECHADO">⚡ FECHADO</div>
        <div style="margin-top:8px;font-size:10px;color:var(--text2)">
          Falhas: <span id="circuitFailures" style="color:#fff">0</span>
          / <span id="circuitThreshold">5</span>
        </div>
      </div>
    </div>

    <div>
      <div class="section-title">Locks Ativos (2PL)</div>
      <div id="lockViz" class="lock-viz">
        <span class="no-locks">Nenhum lock ativo</span>
      </div>
      <div style="margin-top:8px;font-size:10px;color:var(--text2)">
        Contas bloqueadas: <span id="lockedAccounts" style="color:var(--accent)">0</span>
      </div>
    </div>

    <div>
      <div class="section-title">Contas</div>
      <div id="accountsList"></div>
    </div>
  </aside>

  <!-- CONTENT -->
  <main class="content">

    <!-- Controls -->
    <div class="chart-card">
      <div class="chart-title">
        Operações Manuais
        <span style="color:var(--accent2);font-size:10px">Testar o sistema</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">De</label>
            <select class="form-select" id="fromAcc"></select>
          </div>
          <div class="form-group">
            <label class="form-label">Para</label>
            <select class="form-select" id="toAcc"></select>
          </div>
          <div class="form-group">
            <label class="form-label">Valor (R$)</label>
            <input class="form-input" type="number" id="txAmount" value="100" min="1" style="width:120px">
          </div>
          <button class="btn primary" onclick="doTransfer()">↗ Transferir</button>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Conta</label>
            <select class="form-select" id="singleAcc"></select>
          </div>
          <div class="form-group">
            <label class="form-label">Valor (R$)</label>
            <input class="form-input" type="number" id="singleAmount" value="500" min="1" style="width:120px">
          </div>
          <button class="btn success" onclick="doDeposit()">↓ Depositar</button>
          <button class="btn danger" onclick="doWithdraw()">↑ Sacar</button>
          <button class="btn" onclick="doStressTest()">⚡ Stress Test</button>
          <button class="btn" onclick="doFreezeToggle()">🔒 Congelar/Descongelar</button>
        </div>
        <div id="txResult" style="font-size:11px;padding:6px 10px;border-radius:4px;display:none"></div>
      </div>
    </div>

    <!-- Charts -->
    <div class="charts-row">
      <div class="chart-card">
        <div class="chart-title">
          Transações por Segundo
          <span class="kpi-value accent" style="font-size:18px" id="chartTPS">0</span>
        </div>
        <div class="sparkline-container">
          <canvas id="tpsChart" class="sparkline"></canvas>
        </div>
      </div>
      <div class="chart-card">
        <div class="chart-title">
          Latência Média (ms)
          <span class="kpi-value" style="font-size:18px" id="chartLatency">0ms</span>
        </div>
        <div class="sparkline-container">
          <canvas id="latencyChart" class="sparkline"></canvas>
        </div>
      </div>
    </div>

    <!-- Transactions -->
    <div class="table-card">
      <div class="table-header">
        <div class="table-title">📋 Histórico de Transações</div>
        <div style="font-size:10px;color:var(--text2)" id="txCount">0 transações</div>
      </div>
      <div style="max-height:260px;overflow-y:auto">
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Tipo</th><th>De</th><th>Para</th>
              <th>Valor</th><th>Status</th><th>Latência</th><th>Hora</th>
            </tr>
          </thead>
          <tbody id="txTable"></tbody>
        </table>
      </div>
    </div>

    <!-- Alerts + Security -->
    <div class="security-grid">
      <div class="alerts-panel">
        <div class="table-header">
          <div class="table-title">⚠ Alertas em Tempo Real</div>
          <div style="font-size:10px;color:var(--text2)" id="alertCount">0 alertas</div>
        </div>
        <div id="alertsList" style="max-height:200px;overflow-y:auto"></div>
      </div>

      <div class="chart-card">
        <div class="chart-title">
          🛡 Segurança & Auditoria
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          <div id="integrityBadge" class="integrity-badge ok">
            ✓ Integridade do Log Verificada
          </div>
          <div style="font-size:10px;color:var(--text2)">
            Duplicatas bloqueadas: <span id="dupsBlocked" style="color:var(--warn);font-weight:600">0</span>
          </div>
          <div style="font-size:10px;color:var(--text2)">
            Flags de fraude: <span id="fraudFlags" style="color:var(--danger);font-weight:600">0</span>
          </div>
        </div>
      </div>
    </div>

    <!-- WAL Log -->
    <div class="log-panel">
      <div class="table-header">
        <div class="table-title">📝 Write-Ahead Log (WAL)</div>
        <div style="font-size:10px;color:var(--text2)" id="walCount">0 entradas</div>
      </div>
      <div class="wal-area" id="walLog"></div>
    </div>

  </main>
</div>
</div>

<script>
// ─── Estado global ────────────────────────────────────────────
let accounts = [];
let tpsData = new Array(30).fill(0);
let latencyData = new Array(30).fill(0);
let tpsCtx, latencyCtx;
let tpsChart, latencyChart;

// ─── Inicialização ────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  initCharts();
  fetchData();
  setInterval(fetchData, 1500);
});

function initCharts() {
  function makeChart(canvasId, color, label) {
    const canvas = document.getElementById(canvasId);
    const ctx = canvas.getContext('2d');
    return { ctx, color, label, data: new Array(30).fill(0) };
  }
  tpsChart = makeChart('tpsChart', '#00d4ff', 'TX/s');
  latencyChart = makeChart('latencyChart', '#00ff88', 'Latência ms');
}

function drawSparkline(chart, data) {
  const canvas = document.getElementById(chart === tpsChart ? 'tpsChart' : 'latencyChart');
  const ctx = chart.ctx;
  const W = canvas.offsetWidth || 400;
  const H = 60;
  canvas.width = W;
  canvas.height = H;
  ctx.clearRect(0, 0, W, H);

  const max = Math.max(...data, 1);
  const pts = data.map((v, i) => [i / (data.length - 1) * W, H - (v / max) * H * 0.9 - 4]);

  // Gradient fill
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, chart.color + '33');
  grad.addColorStop(1, chart.color + '00');

  ctx.beginPath();
  ctx.moveTo(pts[0][0], H);
  pts.forEach(([x, y]) => ctx.lineTo(x, y));
  ctx.lineTo(pts[pts.length-1][0], H);
  ctx.fillStyle = grad;
  ctx.fill();

  // Line
  ctx.beginPath();
  pts.forEach(([x, y], i) => i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y));
  ctx.strokeStyle = chart.color;
  ctx.lineWidth = 2;
  ctx.stroke();
}

// ─── Fetch data ────────────────────────────────────────────────
async function fetchData() {
  try {
    const res = await fetch('/api/dashboard');
    const data = await res.json();
    updateUI(data);
  } catch(e) {
    console.error('Fetch error:', e);
  }
}

function updateUI(data) {
  const s = data.summary;
  const now = new Date().toLocaleTimeString('pt-BR');
  document.getElementById('lastUpdate').textContent = `Atualizado ${now}`;

  // KPIs
  document.getElementById('kpiTPS').textContent = s.tps;
  document.getElementById('chartTPS').textContent = s.tps;
  document.getElementById('kpiSuccessRate').textContent = s.success_rate + '%';
  document.getElementById('kpiCommitted').textContent = s.total_committed;
  document.getElementById('kpiFailed').textContent = s.total_failed;
  document.getElementById('kpiVolume').textContent = 'R$ ' + s.total_volume.toLocaleString('pt-BR', {minimumFractionDigits:2});

  // Charts
  const latStats = data.metrics?.tx_latency_ms?.stats || {};
  const latSeries = data.metrics?.tx_latency_ms?.series || [];
  const tpsSeries = data.metrics?.tx_per_second?.series || [];

  document.getElementById('chartLatency').textContent = (latStats.mean || 0).toFixed(1) + 'ms';

  if (tpsSeries.length > 0) {
    tpsData = tpsSeries.map(p => p.v);
  } else {
    tpsData.push(s.tps);
    if (tpsData.length > 30) tpsData.shift();
  }

  if (latSeries.length > 0) {
    latencyData = latSeries.map(p => p.v);
  } else {
    latencyData.push(latStats.mean || 0);
    if (latencyData.length > 30) latencyData.shift();
  }

  drawSparkline(tpsChart, tpsData);
  drawSparkline(latencyChart, latencyData);

  // Engine stats
  const es = data.engine_stats || {};
  const cb = es.circuit_breaker || {};
  const ls = es.lock_status || {};

  const stateEl = document.getElementById('circuitState');
  stateEl.textContent = (cb.state === 'FECHADO' ? '⚡' : cb.state === 'ABERTO' ? '🔴' : '🟡') + ' ' + (cb.state || 'FECHADO');
  stateEl.className = 'circuit-state ' + (cb.state || 'FECHADO');
  document.getElementById('circuitFailures').textContent = cb.failure_count || 0;
  document.getElementById('circuitThreshold').textContent = cb.failure_threshold || 5;

  // Locks
  const locked = ls.locked_accounts || 0;
  document.getElementById('lockedAccounts').textContent = locked;
  const lockViz = document.getElementById('lockViz');
  if (locked > 0) {
    lockViz.innerHTML = Array(locked).fill(0).map((_, i) =>
      `<span class="lock-pill">🔒 LOCK ${i+1}</span>`
    ).join('');
  } else {
    lockViz.innerHTML = '<span class="no-locks">✓ Nenhum lock ativo</span>';
  }

  // Accounts
  accounts = data.accounts || [];
  renderAccounts(accounts);
  updateSelects(accounts);

  // Transactions
  renderTransactions(data.transactions || []);

  // Alerts
  const alerts = data.alerts || [];
  document.getElementById('alertCount').textContent = alerts.length + ' alertas';
  renderAlerts(alerts);

  // Security
  const sec = data.security || {};
  const intBadge = document.getElementById('integrityBadge');
  intBadge.className = 'integrity-badge ' + (sec.audit_integrity ? 'ok' : 'fail');
  intBadge.textContent = sec.audit_integrity ? '✓ Integridade do Log Verificada' : '✗ Log Comprometido!';
  document.getElementById('fraudFlags').textContent = (sec.fraud_flags || []).length;

  // Dups
  const dupStats = data.metrics?.duplicates_blocked?.stats || {};
  document.getElementById('dupsBlocked').textContent = dupStats.count || 0;

  // WAL
  renderWAL(data.wal_log || []);
  document.getElementById('walCount').textContent = (es.wal_entries || 0) + ' entradas';
}

function renderAccounts(accs) {
  const el = document.getElementById('accountsList');
  el.innerHTML = accs.map(a => {
    const tags = [];
    if (a.frozen) tags.push('<span class="account-tag tag-frozen">CONGELADA</span>');
    if (a.risk_score > 30) tags.push(`<span class="account-tag tag-risk">RISCO ${a.risk_score}</span>`);
    return `
      <div class="account-card ${a.frozen?'frozen':''} ${a.risk_score>30?'high-risk':''}">
        <div class="account-header">
          <div class="account-name">${a.owner}</div>
          <div class="account-balance">R$${a.balance.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2})}</div>
        </div>
        <div class="account-meta">
          <span>${a.id.substring(0,8)}…</span>
          <span>v${a.version}</span>
          ${tags.join('')}
        </div>
      </div>
    `;
  }).join('');
}

function updateSelects(accs) {
  const opts = accs.map(a => `<option value="${a.id}">${a.owner} (${a.id.substring(0,6)})</option>`).join('');
  ['fromAcc','toAcc','singleAcc'].forEach(id => {
    const sel = document.getElementById(id);
    const cur = sel.value;
    sel.innerHTML = opts;
    if (cur) sel.value = cur;
  });
}

function renderTransactions(txs) {
  const tbody = document.getElementById('txTable');
  document.getElementById('txCount').textContent = txs.length + ' transações';
  
  const accsMap = {};
  accounts.forEach(a => accsMap[a.id] = a.owner);
  
  tbody.innerHTML = txs.slice(0,30).map(tx => {
    const from = tx.from_account ? (accsMap[tx.from_account] || tx.from_account.substring(0,8)) : '—';
    const to = tx.to_account ? (accsMap[tx.to_account] || tx.to_account.substring(0,8)) : '—';
    const time = new Date(tx.created_at).toLocaleTimeString('pt-BR');
    return `
      <tr>
        <td style="color:var(--text2)">${tx.transaction_id.substring(0,8)}…</td>
        <td class="tx-type">${tx.tx_type}</td>
        <td>${from}</td>
        <td>${to}</td>
        <td class="tx-amount">R$${tx.amount.toLocaleString('pt-BR',{minimumFractionDigits:2})}</td>
        <td><span class="tx-status status-${tx.status}">${tx.status}</span></td>
        <td class="tx-time">${tx.execution_time_ms.toFixed(1)}ms</td>
        <td class="tx-time">${time}</td>
      </tr>
    `;
  }).join('');
}

function renderAlerts(alerts) {
  const el = document.getElementById('alertsList');
  if (!alerts.length) {
    el.innerHTML = '<div class="empty-state">✓ Nenhum alerta ativo</div>';
    return;
  }
  el.innerHTML = alerts.slice(0,15).map(a => {
    const time = new Date(a.timestamp).toLocaleTimeString('pt-BR');
    return `
      <div class="alert-item">
        <div class="alert-dot ${a.severity}"></div>
        <div style="flex:1">
          <div class="alert-name">${a.name}</div>
          <div class="alert-msg">${a.message}</div>
        </div>
        <div class="alert-time">${time}</div>
      </div>
    `;
  }).join('');
}

function renderWAL(entries) {
  const el = document.getElementById('walLog');
  if (!entries.length) {
    el.innerHTML = '<div class="empty-state">WAL vazio</div>';
    return;
  }
  el.innerHTML = entries.slice(0,50).reverse().map(e => {
    const time = new Date(e.timestamp).toLocaleTimeString('pt-BR');
    return `
      <div class="log-entry">
        <span class="lsn">LSN-${e.lsn}</span>
        <span class="op">${e.operation}</span>
        <span style="color:var(--text2)">${e.transaction_id.substring(0,8)}… · ${time}</span>
      </div>
    `;
  }).join('');
}

// ─── Operações ─────────────────────────────────────────────────
function showResult(msg, ok) {
  const el = document.getElementById('txResult');
  el.style.display = 'block';
  el.style.background = ok ? 'rgba(0,255,136,0.1)' : 'rgba(255,71,87,0.1)';
  el.style.color = ok ? 'var(--accent2)' : 'var(--danger)';
  el.style.border = `1px solid ${ok ? 'rgba(0,255,136,0.2)' : 'rgba(255,71,87,0.2)'}`;
  el.textContent = msg;
  setTimeout(() => el.style.display = 'none', 4000);
}

async function doTransfer() {
  const from = document.getElementById('fromAcc').value;
  const to = document.getElementById('toAcc').value;
  const amount = parseFloat(document.getElementById('txAmount').value);
  if (from === to) return showResult('Selecione contas diferentes', false);
  try {
    const res = await fetch('/api/transfer', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({from_account:from, to_account:to, amount})
    });
    const data = await res.json();
    const ok = data.status === 'CONFIRMADA';
    showResult(ok ? `✓ Transferência R$${amount} confirmada` : `✗ ${data.error || data.status}`, ok);
    fetchData();
  } catch(e) { showResult('Erro de conexão', false); }
}

async function doDeposit() {
  const acc = document.getElementById('singleAcc').value;
  const amount = parseFloat(document.getElementById('singleAmount').value);
  try {
    const res = await fetch('/api/deposit', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({account_id:acc, amount})
    });
    const data = await res.json();
    showResult(data.status === 'CONFIRMADA' ? `✓ Depósito R$${amount} realizado` : `✗ ${data.error || data.status}`, data.status === 'CONFIRMADA');
    fetchData();
  } catch(e) { showResult('Erro de conexão', false); }
}

async function doWithdraw() {
  const acc = document.getElementById('singleAcc').value;
  const amount = parseFloat(document.getElementById('singleAmount').value);
  try {
    const res = await fetch('/api/withdraw', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({account_id:acc, amount})
    });
    const data = await res.json();
    showResult(data.status === 'CONFIRMADA' ? `✓ Saque R$${amount} realizado` : `✗ ${data.error || data.status}`, data.status === 'CONFIRMADA');
    fetchData();
  } catch(e) { showResult('Erro de conexão', false); }
}

async function doStressTest() {
  showResult('⚡ Executando stress test com 20 threads simultâneas...', true);
  try {
    const res = await fetch('/api/stress_test', {method:'POST'});
    const data = await res.json();
    showResult(`✓ Stress test concluído: ${data.committed} confirmadas, ${data.failed} falhas, ${data.deadlocks} deadlocks`, true);
    fetchData();
  } catch(e) { showResult('Erro no stress test', false); }
}

async function doFreezeToggle() {
  const acc = document.getElementById('singleAcc').value;
  const accData = accounts.find(a => a.id === acc);
  const action = accData?.frozen ? 'unfreeze' : 'freeze';
  try {
    const res = await fetch(`/api/${action}`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({account_id:acc})
    });
    const data = await res.json();
    showResult(data.success ? `✓ Conta ${action === 'freeze' ? 'congelada' : 'descongelada'}` : '✗ Erro', data.success);
    fetchData();
  } catch(e) { showResult('Erro de conexão', false); }
}
</script>
</body>
</html>'''


# ─────────────────────────────────────────────────────────────
# FLASK API SERVER
# ─────────────────────────────────────────────────────────────

def create_app(bank_system):
    """Cria app Flask com todas as rotas."""
    try:
        from flask import Flask, jsonify, request, Response
    except ImportError:
        print("Flask não instalado. Execute: pip install flask")
        return None

    app = Flask(__name__)
    import logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.WARNING)

    @app.route('/')
    def index():
        return Response(DASHBOARD_HTML, mimetype='text/html')

    @app.route('/api/dashboard')
    def dashboard():
        data = bank_system.get_dashboard()
        txs = bank_system.engine.get_transactions(limit=50)
        data['transactions'] = [t.to_dict() for t in txs]
        data['wal_log'] = bank_system.engine.wal.get_log()[-50:]
        return jsonify(data)

    @app.route('/api/transfer', methods=['POST'])
    def transfer():
        body = request.json
        tx = bank_system.transfer(
            body['from_account'], body['to_account'], body['amount'],
            client_id=request.remote_addr or 'web'
        )
        if isinstance(tx, dict):
            return jsonify(tx), 429
        result = tx.to_dict()
        if tx.error_message:
            result['error'] = tx.error_message
        return jsonify(result)

    @app.route('/api/deposit', methods=['POST'])
    def deposit():
        body = request.json
        tx = bank_system.deposit(body['account_id'], body['amount'],
                                  client_id=request.remote_addr or 'web')
        if isinstance(tx, dict):
            return jsonify(tx), 429
        result = tx.to_dict()
        if tx.error_message:
            result['error'] = tx.error_message
        return jsonify(result)

    @app.route('/api/withdraw', methods=['POST'])
    def withdraw():
        body = request.json
        tx = bank_system.withdraw(body['account_id'], body['amount'],
                                   client_id=request.remote_addr or 'web')
        if isinstance(tx, dict):
            return jsonify(tx), 429
        result = tx.to_dict()
        if tx.error_message:
            result['error'] = tx.error_message
        return jsonify(result)

    @app.route('/api/freeze', methods=['POST'])
    def freeze():
        body = request.json
        ok = bank_system.engine.freeze_account(body['account_id'])
        return jsonify({"success": ok})

    @app.route('/api/unfreeze', methods=['POST'])
    def unfreeze():
        body = request.json
        ok = bank_system.engine.unfreeze_account(body['account_id'])
        return jsonify({"success": ok})

    @app.route('/api/stress_test', methods=['POST'])
    def stress_test():
        import threading, random
        accounts = bank_system.engine.get_all_accounts()
        results = []
        lock = threading.Lock()

        def worker():
            src = random.choice(accounts)
            dst = random.choice([a for a in accounts if a.account_id != src.account_id])
            amount = round(random.uniform(10, 300), 2)
            import time
            tx = bank_system.transfer(src.account_id, dst.account_id, amount,
                                       idempotency_key=f"ST-{time.time_ns()}")
            with lock:
                if hasattr(tx, 'status'):
                    results.append(tx.status.value)

        from core.engine import TransactionStatus
        threads = [threading.Thread(target=worker) for _ in range(20)]
        for t in threads: t.start()
        for t in threads: t.join()

        committed = sum(1 for r in results if r == TransactionStatus.COMMITTED.value)
        failed = sum(1 for r in results if r == TransactionStatus.ROLLED_BACK.value)
        deadlocks = sum(1 for r in results if r == TransactionStatus.DEADLOCKED.value)

        return jsonify({"committed": committed, "failed": failed, "deadlocks": deadlocks, "total": len(results)})

    return app


def run_web_dashboard(bank_system, port: int = 5000):
    """Inicia o dashboard web."""
    app = create_app(bank_system)
    if not app:
        return
    
    print(f"\n{'═'*60}")
    print(f"  🌐 DASHBOARD DISPONÍVEL EM:")
    print(f"     http://localhost:{port}")
    print(f"{'═'*60}\n")
    
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
